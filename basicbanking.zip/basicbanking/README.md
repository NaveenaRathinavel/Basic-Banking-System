BASIC BANKING SYSTEM


A dynamic Web Application used to transfer money between multiple users.
Stack used:
Front-end - HTML, CSS, Bootstrap & Javascript 
Back-end - PHP 
Database - MySQL   


Flow of the Website: Home Page > View all Users > Select and View one User > Transfer Money > Select reciever > View all Users > View Transfer History.
